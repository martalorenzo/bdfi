#FUNCIONAMIENTO EN LOCAL
#Instalación de paquetes

sudo apt install -y openjdk-8-jdk
sudo apt install -y python3-pip
sudo apt install -y python-pip

#SBT
echo "deb https://dl.bintray.com/sbt/debian /" | sudo tee -a /etc/apt/sources.list.d/sbt.list
curl -sL "https://keyserver.ubuntu.com/pks/lookup?op=get&search=0x2EE0EA64E40A89B84B2DF73499E82A75642AC823" | sudo apt-key add
sudo apt-get update
sudo apt-get install sbt

#MONGO
wget -qO - https://www.mongodb.org/static/pgp/server-4.4.asc | sudo apt-key add -
echo "deb [ arch=amd64,arm64 ] https://repo.mongodb.org/apt/ubuntu bionic/mongodb-org/4.4 multiverse" | sudo tee /etc/apt/sources.list.d/mongodb-org-4.4.list
sudo apt-get update
sudo apt-get install -y mongodb-org

#Zookeeper, kafka y spark
tar -xvzf apache-zookeeper-3.6.2-bin.tar.gz 
tar -xvzf kafka_2.12-2.4.0.tgz 
tar -xvzf spark-2.4.0-bin-hadoop2.7.tgz 

#Clonar el repositorio de la práctica y descargar los datoslss

git clone https://github.com/ging/practica_big_data_2019
cd practica_big_data_2019/
resources/download_data.sh 

#Dentro de la carpeta practica_big_data_2019,se instalan los requisitos
pip3 install -r requirements.txt 

# Se inicia zookeeper y kafka y se crea un topic
cd Descargas/kafka_2.12-2.3.0/
bin/zookeeper-server-start.sh config/zookeeper.properties 
bin/kafka-server-start.sh config/server.properties 
bin/kafka-topics.sh --create --zookeeper localhost:2181 --replication-factor 1 --partitions 1 --topic flight_delay_classification_request
bin/kafka-topics.sh --list --zookeeper localhost:2181

# Se vuelve a la carpeta de la práctica,se incia mongo y se ejecuta el script para importar y se genera la carpeta models
cd  Descargas/practica_big_data_2019
service mongod start
service mongod status
mkdir data 
#cp origin_dest_distances.jsonl data/
 ./resources/import_distances.sh 

# Para entrenar el modelo se establecen las variables de JAVA_HOME y de SPARK_HOME y se entrena el modelo. 
export JAVA_HOME=/usr/lib/jvm/java-1.8.0-openjdk-amd64
export SPARK_HOME=/home/marta/Descargas/spark-2.4.0-bin-hadoop2.7
#cp simple_flight_delay_features.jsonl.bz2 data/
python3 resources/train_spark_mllib_model.py .

#1.a CON INTELIJ se ejecuta la clase MakePrediction después de entrenar el modelo
#Cambiar en MakePrediction 
 val base_path= "/home/marta/Descargas/practica_big_data_2019"
cd /home/marta/Descargas/practica_big_data_2019/flight_prediction
sbt
compile
runMain es.upm.dit.ging.predictor.MakePrediction

#Una vez que se ha ejecutado la clase MakePrediction con Intelij se lanza el servidor
export PROJECT_HOME=/home/marta/Descargas/practica_big_data_2019
#La primera vez que se ejecuta da el error del import joblib
python3 resources/web/predict_flask.py
#Finalmente, se accede a la siguiente dirección web y nuestra aplicación estará lista para realizar peticiones y devolver el retraso de los vuelos:
"http://localhost:5000/flights/delays/predict_kafka")

#Por último se comprueba que se han incoporado los datos a mongo
mongo
show dbs
use agile_data_science
db.flight_delay_classification_response.find().pretty()

#MEJORA 1
#En vez de ejecutar con Intelij (1.a) se usa spark-sumit para ejecutar el job de predicción

#Cambiar en MakePrediction (hecho anteriormente)
 val base_path= "/home/marta/Descargas/practica_big_data_2019"

#En la carpeta Descargas/practica_big_data_2019/flight_prediction
sbt compile
sbt package

#Con esto se genera un fichero .jar en Descargas/practica_big_data_2019/flight_predictio/target/scala-2.11

#Ejecutas el comando spark sumit en la carpeta de spark 
#Problemas con las versiones se tuvo que cambiar el build.sbt
bin/spark-submit --class es.upm.dit.ging.predictor.MakePrediction --master local --packages org.mongodb.spark:mongo-spark-connector_2.11:2.3.2,org.apache.spark:spark-sql-kafka-0-10_2.11:2.4.0 /home/marta/Descargas/practica_big_data_2019/flight_prediction/target/scala-2.11/flight_prediction_2.11-0.1.jar 

#MEJORA 2
#Se ha hecho el docker-compose para interconectar los servicios dockerizados
#Para el caso de zookeeper,kafka y mongo se ha elegido una imagen de docker-hub
#Para el caso del servidor se ha creado un Dockerfile y se han ejecutado los siguientes comandos
sudo docker build -t bdfi/web .
sudo docker run bdfi/web

#Se ejecuta el docker-compose
sudo docker-compose up -d
#Para ver si se han levantado los contenedores
sudo docker ps -a

docker exec -it mongo mongoimport -d agile_data_science -c origin_dest_distances --file /practica_big_data_2019/data/origin_dest_distances.jsonl




 


